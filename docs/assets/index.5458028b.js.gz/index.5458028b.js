
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as e,d as a,u as s,b as i,H as n,j as t,l as d,T as r,O as o,t as m,h as l,e as c,f,g as p,k as u,L as j,P as b,n as v,J as x}from"./index.015bb7ab.js";/* empty css                */import{_ as h}from"./index.2f891fd2.js";import k from"./index.4c8562db.js";import _ from"./index.0a900349.js";import"./el-button.2b4a4c12.js";import"./index.8bfffa1c.js";import"./index2.3d38e54c.js";import"./index2.7bb86833.js";/* empty css                  */import"./index2.088904f4.js";import"./error2.13f96d52.js";import"./index2.d65d1d94.js";const y={key:0},g={class:"header-container"},M={class:"main"},C={class:"nav"},H=["onClick"],O={key:0},w=a({name:"Header"});var I=e(Object.assign(w,{setup(e){const a=s(),w=i(),I=o("switchMenu");return(e,s)=>{const i=h,o=n;return m(),t(r,{name:"header"},{default:d((()=>["pc"===l(a).mode&&"head"===l(a).menu.menuMode?(m(),c("header",y,[f("div",g,[f("div",M,[p(k),u(" 顶部模式 "),f("div",C,[(m(!0),c(j,null,b(l(w).allMenus,((e,a)=>(m(),c(j,null,[e.children&&0!==e.children.length?(m(),c("div",{key:a,class:v(["item",{active:a==l(w).actived}]),onClick:e=>l(I)(a)},[p(o,null,{default:d((()=>[e.meta.icon?(m(),t(i,{key:0,name:e.meta.icon},null,8,["name"])):u("v-if",!0)])),_:2},1024),e.meta.title?(m(),c("span",O,x(e.meta.title),1)):u("v-if",!0)],10,H)):u("v-if",!0)],64)))),256))])]),p(_)])])):u("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-339849a1"]]);export{I as default};
//# sourceMappingURL=index.5458028b.js.map
